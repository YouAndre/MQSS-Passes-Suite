// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['rz', 'sx', 'x', 'ecr', 'measure', 'barrier']
// Coupling List: [[0, 1], [0, 7], [1, 2], [7, 6], [2, 3], [4, 3], [4, 5], [6, 5]]

OPENQASM 2.0;
include "qelib1.inc";
opaque ecr q0,q1;
qreg q[8];
creg meas[5];
rz(-pi/2) q[0];
sx q[0];
rz(-pi) q[0];
rz(-pi/2) q[1];
sx q[1];
rz(-pi) q[1];
rz(-pi/2) q[2];
sx q[2];
rz(-pi) q[2];
rz(-pi) q[3];
sx q[3];
rz(-pi) q[3];
rz(pi/2) q[4];
sx q[4];
ecr q[4],q[3];
sx q[3];
rz(-pi/2) q[3];
ecr q[2],q[3];
rz(-pi) q[2];
sx q[2];
ecr q[1],q[2];
rz(-pi) q[1];
sx q[1];
ecr q[0],q[1];
rz(pi/2) q[0];
sx q[0];
rz(pi/2) q[0];
rz(-pi/2) q[1];
sx q[1];
rz(pi/2) q[1];
rz(-pi/2) q[2];
sx q[2];
rz(pi/2) q[2];
rz(-pi/2) q[3];
sx q[3];
rz(pi/2) q[3];
x q[4];
barrier q[0],q[1],q[2],q[3],q[4];
measure q[0] -> meas[0];
measure q[1] -> meas[1];
measure q[2] -> meas[2];
measure q[3] -> meas[3];
measure q[4] -> meas[4];