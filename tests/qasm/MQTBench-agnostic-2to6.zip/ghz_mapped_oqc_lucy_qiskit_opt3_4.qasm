// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['rz', 'sx', 'x', 'ecr', 'measure', 'barrier']
// Coupling List: [[0, 1], [0, 7], [1, 2], [7, 6], [2, 3], [4, 3], [4, 5], [6, 5]]

OPENQASM 2.0;
include "qelib1.inc";
opaque ecr q0,q1;
qreg q[8];
creg meas[4];
rz(pi/2) q[0];
sx q[0];
rz(-0.9605739910772786) q[0];
rz(-pi) q[1];
sx q[1];
rz(-pi) q[1];
rz(pi/2) q[6];
sx q[6];
rz(-1.1204322414092989) q[6];
sx q[6];
rz(pi/2) q[6];
rz(-pi/2) q[7];
sx q[7];
rz(-2.7891730254494114) q[7];
ecr q[7],q[6];
rz(pi/2) q[6];
sx q[6];
rz(1.120432241409297) q[6];
rz(1.9232159549352765) q[7];
sx q[7];
rz(-0.6893905099672857) q[7];
sx q[7];
rz(-pi/2) q[7];
ecr q[0],q[7];
rz(0.6102223357176175) q[0];
sx q[0];
rz(-pi) q[0];
ecr q[0],q[1];
x q[0];
rz(pi/2) q[7];
sx q[7];
rz(2.4522021436225074) q[7];
barrier q[1],q[0],q[7],q[6];
measure q[1] -> meas[0];
measure q[0] -> meas[1];
measure q[7] -> meas[2];
measure q[6] -> meas[3];