// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// TKET version: 1.25.0
// Used Gate Set: ['rxx', 'rz', 'ry', 'rx', 'measure', 'barrier']

OPENQASM 2.0;
include "qelib1.inc";

qreg q[4];
creg c[3];
rx(0.5*pi) q[0];
rx(0.5*pi) q[1];
rx(0.5*pi) q[2];
rx(1.5*pi) q[3];
rz(1.5*pi) q[0];
rz(1.5*pi) q[1];
rz(1.5*pi) q[2];
rz(1.5*pi) q[3];
rx(1.5*pi) q[0];
rx(1.5*pi) q[1];
rx(1.5*pi) q[2];
rx(0.5*pi) q[3];
rz(0.5*pi) q[0];
rz(0.5*pi) q[1];
rz(0.5*pi) q[2];
ry(0.5*pi) q[0];
ry(0.5*pi) q[1];
ry(0.5*pi) q[2];
rxx(0.5*pi) q[0],q[3];
ry(3.5*pi) q[0];
rx(3.5*pi) q[3];
rz(3.5*pi) q[0];
rx(0.5*pi) q[3];
rx(0.5*pi) q[0];
rxx(0.5*pi) q[1],q[3];
rz(0.5*pi) q[0];
ry(3.5*pi) q[1];
rx(3.5*pi) q[3];
rz(3.5*pi) q[1];
rx(0.5*pi) q[3];
rx(0.5*pi) q[1];
rxx(0.5*pi) q[2],q[3];
rz(0.5*pi) q[1];
ry(3.5*pi) q[2];
rx(3.5*pi) q[3];
rz(3.5*pi) q[2];
rz(1.0*pi) q[3];
rx(0.5*pi) q[2];
rz(0.5*pi) q[2];
barrier q[0],q[1],q[2],q[3];
measure q[0] -> c[0];
measure q[1] -> c[1];
measure q[2] -> c[2];
