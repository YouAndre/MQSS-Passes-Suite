// Benchmark was created by MQT Bench on 2024-03-18
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['rz', 'sx', 'x', 'ecr', 'measure', 'barrier']
// Coupling List: [[0, 1], [0, 7], [1, 2], [7, 6], [2, 3], [4, 3], [4, 5], [6, 5]]

OPENQASM 2.0;
include "qelib1.inc";
opaque ecr q0,q1;
qreg q[8];
creg meas[2];
rz(-pi/2) q[0];
sx q[0];
rz(-1.2535535107721882) q[0];
rz(0.32175055439664124) q[7];
sx q[7];
rz(pi/2) q[7];
ecr q[0],q[7];
rz(2.9847769682453915) q[7];
sx q[7];
rz(-2.2652945924214523) q[7];
sx q[7];
rz(-0.15681568534439982) q[7];
ecr q[0],q[7];
rz(-1.888039142817604) q[0];
sx q[0];
rz(-pi/2) q[0];
rz(-1.2725245528241058) q[7];
sx q[7];
rz(-1.2623499982390847) q[7];
sx q[7];
rz(-1.4777325980704799) q[7];
barrier q[0],q[7];
measure q[0] -> meas[0];
measure q[7] -> meas[1];