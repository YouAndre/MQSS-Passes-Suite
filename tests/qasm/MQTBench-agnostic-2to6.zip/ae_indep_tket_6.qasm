// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// TKET version: 1.25.0

OPENQASM 2.0;
include "qelib1.inc";

qreg eval[5];
qreg q[1];
creg meas[6];
h eval[0];
h eval[1];
h eval[2];
h eval[3];
h eval[4];
ry(0.29516723530086647*pi) q[0];
u1(0.0*pi) eval[0];
u1(0.0*pi) eval[1];
u1(0.0*pi) eval[2];
u1(0.0*pi) eval[3];
u1(0.0*pi) eval[4];
u1(0.0*pi) q[0];
cx eval[0],q[0];
u3(3.7048327646991335*pi,0.0*pi,0.0*pi) q[0];
cx eval[0],q[0];
u3(0.29516723530086647*pi,0.0*pi,0.0*pi) q[0];
u1(0.0*pi) q[0];
cx eval[1],q[0];
u3(3.4096655293982683*pi,0.0*pi,0.0*pi) q[0];
cx eval[1],q[0];
u3(0.5903344706017317*pi,0.0*pi,0.0*pi) q[0];
u1(0.0*pi) q[0];
cx eval[2],q[0];
u3(2.8193310587965335*pi,0.0*pi,0.0*pi) q[0];
cx eval[2],q[0];
u3(1.1806689412034665*pi,0.0*pi,0.0*pi) q[0];
u1(0.0*pi) q[0];
cx eval[3],q[0];
u3(1.638662117593067*pi,0.0*pi,0.0*pi) q[0];
cx eval[3],q[0];
u3(2.361337882406933*pi,0.0*pi,0.0*pi) q[0];
u1(0.0*pi) q[0];
cx eval[4],q[0];
u3(3.277324235186134*pi,0.0*pi,0.0*pi) q[0];
cx eval[4],q[0];
h eval[4];
u3(0.7226757648138662*pi,0.0*pi,0.0*pi) q[0];
cu1(1.5*pi) eval[3],eval[4];
cu1(1.75*pi) eval[2],eval[4];
h eval[3];
cu1(1.875*pi) eval[1],eval[4];
cu1(1.5*pi) eval[2],eval[3];
cu1(1.9375*pi) eval[0],eval[4];
cu1(1.75*pi) eval[1],eval[3];
h eval[2];
cu1(1.875*pi) eval[0],eval[3];
cu1(1.5*pi) eval[1],eval[2];
cu1(1.75*pi) eval[0],eval[2];
h eval[1];
cu1(1.5*pi) eval[0],eval[1];
h eval[0];
barrier eval[0],eval[1],eval[2],eval[3],eval[4],q[0];
measure eval[0] -> meas[0];
measure eval[1] -> meas[1];
measure eval[2] -> meas[2];
measure eval[3] -> meas[3];
measure eval[4] -> meas[4];
measure q[0] -> meas[5];
