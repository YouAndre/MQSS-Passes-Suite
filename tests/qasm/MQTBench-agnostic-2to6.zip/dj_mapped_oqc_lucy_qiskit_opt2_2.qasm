// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['rz', 'sx', 'x', 'ecr', 'measure', 'barrier']
// Coupling List: [[0, 1], [0, 7], [1, 2], [7, 6], [2, 3], [4, 3], [4, 5], [6, 5]]

OPENQASM 2.0;
include "qelib1.inc";
opaque ecr q0,q1;
qreg q[8];
creg c[1];
rz(-pi/2) q[0];
sx q[0];
rz(-pi) q[7];
sx q[7];
rz(-pi/2) q[7];
ecr q[0],q[7];
rz(pi/2) q[0];
sx q[0];
rz(pi/2) q[0];
barrier q[0],q[7];
measure q[0] -> c[0];