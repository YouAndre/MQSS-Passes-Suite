// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['rz', 'sx', 'x', 'ecr', 'measure', 'barrier']
// Coupling List: [[0, 1], [0, 7], [1, 2], [7, 6], [2, 3], [4, 3], [4, 5], [6, 5]]

OPENQASM 2.0;
include "qelib1.inc";
opaque ecr q0,q1;
qreg q[8];
creg c[2];
rz(pi/2) q[0];
sx q[0];
rz(0.4169066508158057) q[0];
rz(-pi/2) q[6];
sx q[6];
rz(-0.23117329003555653) q[6];
sx q[6];
rz(-pi/2) q[6];
rz(-1.892546881191539) q[7];
sx q[7];
rz(-pi/2) q[7];
ecr q[0],q[7];
rz(1.987702977610704) q[0];
sx q[0];
rz(-pi/2) q[0];
rz(pi/2) q[7];
sx q[7];
rz(-1.8925468811915387) q[7];
ecr q[7],q[6];
rz(pi/2) q[6];
sx q[6];
rz(-1.801969616830453) q[6];
sx q[6];
rz(pi/2) q[6];
rz(-pi/2) q[7];
sx q[7];
rz(-pi/2) q[7];
barrier q[0],q[6],q[7];
measure q[0] -> c[0];
measure q[6] -> c[1];